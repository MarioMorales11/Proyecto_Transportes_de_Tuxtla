<?php
session_start();
if(isset($_SESSION['nombreclientes']))
{
	$clientesSesion=$_SESSION['nombreclientes'];
	$tipoSesion=$_SESSION['tipoclientes'];
}
else
{
	$clientesSesion='';
	$tipoSesion='';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilo.css"/>
    <title>Transportes de Tuxtla</title>
</head>
<body>
    <!--HEADER-->
    <table id="menu" width="100%">
        <tr bgcolor="#363636" height="109px">
            <td align="center"><img src="images/logo.jpg" width="150px" height="100px"></td>
            <td width="50%"><font size="8" face="Trebuchet MS,Arial,Verdana" color="white"><b>Terminal de<br>Transportes de Tuxtla</b></font></td>
            <?php
				if($clientesSesion<>'' && $tipoSesion==2)
					{
			?>
            <td width="8%"><a href="Nosotros/nosotros.php">Nosotros</a></td>
            <td width="8%"><a href="LineasTransporte/lineas.php">Líneas de<br>Transporte</a></td>
            <td width="8%"><a href="Horarios/hora.php">Horarios</a></td>
            <td width="8%"><a href="Autobus/auto.php">Autobuses</a></td>
            <td width="8%"><a href="Reservar/reserva.php">Reservar<br>Boleto</a></td>
            <?php
				}
			?>
            <?php
				if($clientesSesion<>'' && $tipoSesion==1)
					{
			?>
                <td><a href="Administracion/admin.php">Administración</a></td>
                <td width="8%"><a href="#">Líneas de<br>Transporte</a></td>
                <td width="8%"><a href="#">Rutas</a></td>
                <td width="8%"><a href="#">Horarios</a></td>
                <td width="8%"><a href="#">Autobuses</a></td>
			<?php
				}
			?>
        </tr>
    </table>
    <img src="images/banner.png" alt="banner?" width="100%">
    <ul>    
        <a href="cerrarSesion.php" class="button rojo medium radius">
		    <?php 
		if($clientesSesion<>'')
		{
			echo $clientesSesion;
        }			
        else
        {
            echo "Inicia Sesión";
        }
            ?>
        </a>   
    </ul>
    <footer>
        <font size="3" face="Trebuchet MS,Arial,Verdana" color="white">
        <p>&copy; Copyright 2020</p>
        <P>Universidad Autónoma de Chiapas</P>
        </font>
    </footer>
</body>
</html>