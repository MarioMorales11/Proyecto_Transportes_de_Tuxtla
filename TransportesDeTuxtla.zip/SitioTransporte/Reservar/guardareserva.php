<?php
$destino=$_POST['destino'];
$id=$_POST['id'];
include_once '../conex.php';
$mysqlConexion=new mysqli($servidorBD,$usuarioBD,$claveBD,$nombreBD);
$consulta="SELECT `destino` FROM `destino` WHERE `destino` = $_POST[destino]";
if($resultado=$mysqlConexion->query($consulta))
{
    header("Location:../Horarios/hora.php.php");
}
else
{
    header("Location:reserva.php");
}