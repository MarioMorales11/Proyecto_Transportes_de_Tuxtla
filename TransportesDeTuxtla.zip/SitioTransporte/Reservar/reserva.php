<?php
session_start();
if(isset($_SESSION['nombreclientes']))
{
	$clientesSesion=$_SESSION['nombreclientes'];
	$tipoSesion=$_SESSION['tipoclientes'];
}
else
{
	$clientesSesion='';
	$tipoSesion='';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estilo.css"/>
    <link rel="stylesheet" href="../css/Style.css"/>
    <title>Reserva tu boleto</title>
</head>
<body>
    <!--HEADER-->
    <table id="menu" width="100%">
        <tr bgcolor="#363636" height="109px">
			<td width="52%"><font size="8" face="Trebuchet MS,Arial,Verdana" color="white"><a href="index.php"><b>Terminal de Transportes de Tuxtla</b></font></a></td>
		</tr>	
	</table>
<table id="menu" width="100%">
        <?php
			if($clientesSesion<>'' && $tipoSesion==2)
				{
		?>
			<td width="20%"><a href="../Nosotros/nosotros.php"><font size="6" color="black">Nosotros</a></td></font>
        <?php
			}
		?>
        <?php
			if($clientesSesion<>'' && $tipoSesion==1)
				{
		?>
            <td><a href="Administracion/admin.php">Administración</a></td>
            <td width="8%"><a href="#">Líneas de<br>Transporte</a></td>
            <td width="8%"><a href="#">Rutas</a></td>
            <td width="8%"><a href="#">Horarios</a></td>
            <td width="8%"><a href="#">Autobuses</a></td>
		<?php
			}
        ?>
    </tr>    
</table>
<section>
    <h2><font size="6" color="black" class="nosotros">Escoge tu destino...<img src="../images/boleto.png" width="50px" height="40px"></font></h2>
	<div>
        <form action="guardareserva.php" method="post">
            <label>Destino</label>
            <input type="text" name="destino" placeholder="Escoge tu destino" required>
            <label>ID</label>
            <input type="text" name="id"><br>
            <input type="submit" value="GUARDAR">
        </form>
    </div>
</section>
	<ul>    
        <a href="../cerrarSesion.php" class="button rojo medium radius">
		    <?php 
		if($clientesSesion<>'')
		{
			echo $clientesSesion;
        }			
        else
        {
            echo "Inicia Sesión";
        }
            ?>
        </a>   
    </ul>
    <footer>
        <font size="3" face="Trebuchet MS,Arial,Verdana" color="white">
        <p>&copy; Copyright 2020</p>
        <P>Universidad Autónoma de Chiapas</P>
        </font>
    </footer>
</body>
</html>