<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilo.css">
    <link rel="stylesheet" href="css/Style.css">
    <title>Registrate</title>
</head>
<body>
    <!--HEADER-->
    <h1 id="text">Crea tu cuenta</h1>
    <h1 width="60%"<font size="24" face="Trebuchet MS,Arial,Verdana" color="white"><a href="index.php"><b>Terminal de Transportes de Tuxtla</b></font></a></h1>
    <div align="center"><img src="images/login.jpg" width="150px" height="100px" alt="login"></div>
    <section id="main" class="wrapper">
		<div class="container">
            <form action="guardar_usuario.php" method="post">
                        <label>Nombres o Nombre</label>
                        <input type="text" name="nombre" placeholder="Captura tu nombre" required>
                        <label>Apellidos</label>
                        <input type="text" name="apellido" placeholder="Captura tu apellido" required>
                        <label>Teléfono</label>
                        <input type="text" name="tele" placeholder="Captura tu teléfono" required>
                        <label>Direccion</label>
                        <input type="text" name="direccion" placeholder="Captura tu direccion" required>
                        <label>Correo</label>
                        <input type="text" name="correo" placeholder="Captura tu correo" required>
                        <label >Contraseña</label>
                        <input type="password" name="password" placeholder="captura tu contraseña max. 20 caracteres" required>
                <input type="submit" value="Enviar">
            </form>		
		</div>		
    </section>
    <footer>
        <font size="3" face="Trebuchet MS,Arial,Verdana" color="white">
        <p>&copy; Copyright 2020</p>
        <P>Universidad Autónoma de Chiapas</P>
        </font>
    </footer>
</body>
</html>