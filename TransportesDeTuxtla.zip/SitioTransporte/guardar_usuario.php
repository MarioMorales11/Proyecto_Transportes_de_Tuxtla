<?php
$nombre=$_POST['nombre'];
$apellido=$_POST['apellido'];
$telefono=$_POST['tele'];
$direccion=$_POST['direccion'];
$correo=$_POST['correo'];
$password=$_POST['password'];
include_once 'conex.php';
$mysqlConexion=new mysqli($servidorBD,$usuarioBD,$claveBD,$nombreBD);
$consulta="INSERT INTO `clientes`(`Nombre`, `Apellido`, `Tele`, `Direccion`, `Correo`, `Password`, `Tipo`) 
VALUES ('$nombre','$apellido','$telefono','$direccion','$correo','$password',2)";
if($resultado=$mysqlConexion->query($consulta))
{
    header("Location:iniciaSesion.php");
}
else
{
    header("Location:sesion.php");
}
