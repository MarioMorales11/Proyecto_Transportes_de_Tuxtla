<?php
$servidorBD="localhost";
$usuarioBD="root";
$claveBD="";
$nombreBD="transporte";
?>