<?php
session_start();
if(isset($_SESSION['nombreclientes']))
{
	$clientesSesion=$_SESSION['nombreclientes'];
	$tipoSesion=$_SESSION['tipoclientes'];
}
else
{
	$clientesSesion='';
	$tipoSesion='';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estilo.css"/>
    <title>Transportes de Tuxtla</title>
</head>
<body>
<table id="menu" width="100%">
    <tr bgcolor="#363636" height="109px">
        <td width="45%"><font size="8" face="Trebuchet MS,Arial,Verdana" color="white"><a href="../index.php"><b>Terminal de Transportes de Tuxtla</b></a></font></td>
        <?php
			if($clientesSesion<>'' && $tipoSesion==2)
				{
		?>
            <td width="8%"><a href="../LineasTransporte/lineas.php">Líneas de<br>Transporte</a></td>
            <td width="8%"><a href="../Horarios/hora.php">Horarios</a></td>
            <td width="8%"><a href="../Autobus/auto.php">Autobuses</a></td>
            <td width="8%"><a href="../Reservar/reserva.php">Reservar<br>Boleto</a></td>
        <?php
			}
		?>
        <?php
			if($clientesSesion<>'' && $tipoSesion==1)
				{
		?>
            <td><a href="Administracion/admin.php">Administración</a></td>
            <td width="8%"><a href="#">Líneas de<br>Transporte</a></td>
            <td width="8%"><a href="#">Rutas</a></td>
            <td width="8%"><a href="#">Horarios</a></td>
            <td width="8%"><a href="../Autobus/auto.php">Autobuses</a></td>
		<?php
			}
        ?>
    </tr>    
</table>
    <section>
        <table>
            <tr>
                <td>
                    <h4>Nosotros...<br><img src="../images/nosotros.png" width="50px" height="40px"></h4>
                    <p><font size="4" face="Courier New" color="black" class="nosotros">
                    Viaja seguro y comodo, con nosotros donde tendrás variedad de destinos.
                    Con nuestros excelentes autobuses donde te darán la mejor experiencia en viaje, con nuestro personal
                    altamente capacitado.
                    </font></p></td>
                <td align="right">
                    <img src="../images/viaje.jpg" alt="viaja" width="70%" height="50%">
                </td>
            </tr>
            <tr>
                <td>
                    <h4>Misión...<br><img src="../images/mision.png" width="50px" height="40px"></h4>
                    <p><font size="4" face="Courier New" color="black" class="nosotros">
                        Hacer que el usuario se le facilite la reserva de boletos, sin la necesidad de asistir
                        personalmente a la terminal, todo lo que puede hacer de forma digital.
                    </font></p>
                </td>
				<td>
                    <h4>Visión...<br><img src="../images/vision.png" width="50px" height="40px"></h4>
                    <p><font size="4" face="Courier New" color="black" class="nosotros">
                        Queremos lograr que gracias a nuestro sitio web las personas se les facilite 
                        el reservar boletos de viajes. Siempre con la visión de llegar lejos y ser
                        reconocidos a nivel nacional como empresa por nuestro trabajo.
                    </font></p>
                </td>
            </tr>   
            <tr> 
                <td align="left">
                    <img src="../images/auto.jpg" alt="autobuses" width="70%" height="50%">
                </td>
                <td>
                    <h4>Valores...<br><img src="../images/valores.png" width="50px" height="40px"></h4>
                    <p><font size="4" face="Courier New" color="black" class="nosotros">
                        Atender a los clientes de la manera más cordial y respetuosa. Así como a nuestros
                        trabajadores. Porque queremos transmitir el respeto a los usuarios. Somos honestos 
                        y transparentes en lo que hacemos, tenemos la capacidad de analizar las buenas y malas
                        acciones.
                    </font></p>
                </td>
            </tr>
        </table>
    </section>
    <ul>    
        <a href="../cerrarSesion.php" class="button rojo medium radius">
		    <?php 
		if($clientesSesion<>'')
		{
			echo $clientesSesion;
        }			
        else
        {
            echo "Inicia Sesión";
        }
            ?>
        </a>   
    </ul>
    <footer>
        <font size="3" face="Trebuchet MS,Arial,Verdana" color="white">
        <p>&copy; Copyright 2020</p>
        <P>Universidad Autónoma de Chiapas</P>
        </font>
    </footer>
</body>
</html>