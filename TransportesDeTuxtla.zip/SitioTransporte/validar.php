<?php
$correo=$_POST['correo'];
$password=$_POST['password'];
include_once 'conex.php';
$mysqlConexion=new mysqli($servidorBD,$usuarioBD,$claveBD,$nombreBD);
$consulta="SELECT * from clientes WHERE Correo='".$correo."'";
$resultado=$mysqlConexion->query($consulta);
if($registro=$resultado->fetch_array(MYSQLI_ASSOC))
{
    if($registro['Password']==$password)
    {
        session_start();
        $_SESSION['idclientes']=$registro['id'];
        $_SESSION['nombreclientes']=$registro['Correo'];
        $_SESSION['tipoclientes']=$registro['Tipo'];
        header("Location: index.php");
    }
    else{
        header("Location: iniciaSesion.php");
        exit();
    }
}
else{
    header("Location: iniciaSesion.php");
    exit();  
}
?>