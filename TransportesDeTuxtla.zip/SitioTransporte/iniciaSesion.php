<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/Style.css" />
    <link rel="stylesheet" href="css/estilo.css" />
    <title>Inicia Sesion</title>
</head>
<body>
    <!--HEADER-->
	<table id="menu" width="100%">
        <tr bgcolor="#363636" height="109px">
			<td width="52%"><font size="8" face="Trebuchet MS,Arial,Verdana" color="white"><a href="index.php"><b>Terminal de Transportes de Tuxtla</b></font></a></td>
		</tr>	
	</table>
</body>			
<section id="main" class="wrapper">
		<div class="container">
            <form action="validar.php" method="post">
				<div>
					<img src="images/autobus.gif" alt="Inicia tu viaje">
					</div>
					<label>Correo</label>
					<input type="text" name="correo" placeholder="Captura tu correo" required>
					<label >Contraseña</label>
					<input type="password" name="password" placeholder="Captura tu contraseña" required>
					<input type="submit" value="Enviar">
		    </form>					
		</div>
		<ul>
			<li><h1><img src="images/Mano_abajo.png" width="50px" height="40px">¿NO TIENES CUENTA?... CREA UNA AQUI...</h1></li>
		</ul>	
	<div class="button rojo">
		<a href="sesion.php">Obtener cuenta</a><br>
	</div>
</section>	